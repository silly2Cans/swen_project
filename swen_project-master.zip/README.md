This is the readme file.

Struggling to get the environment updated on server.

for the main.py, if you run it,
open the browser with url: http://127.0.0.1:5000/index,  otherwise, it will fail to open
