import pickle
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
# Library Imports.
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# from patsy import dmatrices
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn import metrics
from sklearn.model_selection import cross_validate
# de-serialize model.pkl file into an object called model using pickle

with open('stations.csv', mode='w') as outfile:
    writer = csv.writer(outfile)
    address = []
    available_bike_stands = []
    available_bikes = []
    bike_stands = []
    for rows in reader:
        data_points = (rows[9], rows[2], rows[1], rows[7], int(rows[9] * 2), int(tm))
        engine.execute("INSERT INTO availability2 values (%s,%s,%s,%s,%s,%s)", data_points)
#         print(data_points)




with open('model.pkl', 'rb') as handle:
model = pickle.load(handle)
@route("/predict")
def predict(X_test):
# now we can call various methods over model as as:
# Let X_test be the feature for which we want to predict the output
result = model.predict(X_test)
return jsonify(result)


"""
from __future__ import print_function
from sklearn import svm
from sklearn import datasets

clf = svm.SVC()
iris = datasets.load_iris()
X, y = iris.data, iris.target
clf.fit(X, y)

# method 1: pickle
import pickle
# save
with open('save/clf.pickle', 'wb') as f:
    pickle.dump(clf, f)
# restore
with open('save/clf.pickle', 'rb') as f:
   clf2 = pickle.load(f)
   print(clf2.predict(X[0:1]))

# method 2: joblib
from sklearn.externals import joblib
# Save
joblib.dump(clf, 'save/clf.pkl')
# restore
clf3 = joblib.load('save/clf.pkl')
print(clf3.predict(X[0:1]))


